
<html>
 <head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Software Developement Team">
	  <meta name="keywords" content="software design, affordable software design, professional software design">
  	
    <title>Hardware Store | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
 </head>

 <body>
     
<?php



?>

    <header>
      <div class="container">
        <div id="branding">
          <h1> <span class="highlight">Hardware</span> Store</h1>
        </div>
        <nav>
          <ul>
            <li class="current"><a href="index.html">ΑΡΧΙΚΗ</a></li>
            <li><a href="project.html">Laptop</a></li>
            <li><a href="biography.html">Περιφεριακά</a></li>
			<li><a href="communication.html">Αξεσουάρ</a></li>
			<li><a href="GitGuide.html">Αναβάθμηση</a></li>
			
          </ul>
        </nav>
      </div>
    </header>	
</div>

<div id="slider" >
<figure>
<img src='img/hp.jpg'>
<img src='img/msi.jpg'>
<img src='img/mac.jpg'>
<img src='img/razer.jpg'>
<img src='img/mot.jpg'>
</figure>	
</div>

    <footer>
      <p>Hardware Store &copy; 2019</p>
    </footer>

 </body>
<html>